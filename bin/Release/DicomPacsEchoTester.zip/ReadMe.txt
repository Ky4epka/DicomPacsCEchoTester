﻿Build for Windows x86/x64 OS architecture
Required Net Framework 4.7.2 or above

Help about commands:
	Argument: -help - Help
	Argument: -host - Host address
	Argument: -port - Host address port
	Argument: -clientae - Client AE title
	Argument: -hostae - Host AE title


Result: console output and program exit code